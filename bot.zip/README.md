![a](https://imgur.com/KI4iNyL.png)

## Um projeto totalmente livre

Fizemos este projeto visando quem quer se aprofundar mais em [discord.js](https://discord.js.org/#/) e JavaScript. Combinamos as melhores
práticas do JavaScript para criar um bot simples e funcional que possui muitas funções inscriveis!

## Contribuições

Aceitaremos Pull Requests desde que tenham algum sentido e não sejam gambiarra. Se quiser começar a participar de projetos open-source como este, entre em contato em nosso servidor do Discord.

## Ajuda

Caso tenha alguma dificuldade em entender este código ou por onde começar, nos contate em nosso servidor do Discord.

[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://discord.gg/KbBaftu2zE)
[![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/channel/UCuGLBUyxR7Qvsg9gVN7b0vA)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/gabrielbanaszeski)
